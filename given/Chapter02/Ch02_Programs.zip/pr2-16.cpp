// This program uses Boolean variables.
#include <iostream>
using namespace std;

int main()
{
   bool boolValue;

   boolValue = true;
   cout << boolValue << endl;
	
   boolValue = false;
   cout << boolValue << endl;
   return 0;
}
