// This program prints a message with your name in it. 
#include <iostream>
using namespace std;

int main()
{
   cout << "Hi! It\'s me.\n";
   cout << "I\'m learning to program!\n";
   return 0;
}
